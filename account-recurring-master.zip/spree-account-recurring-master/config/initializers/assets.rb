Rails.application.config.assets.precompile += %w( spree/frontend/stripe.js )
