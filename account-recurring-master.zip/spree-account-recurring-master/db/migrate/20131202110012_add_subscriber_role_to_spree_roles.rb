class AddSubscriberRoleToSpreeRoles < ActiveRecord::Migration[4.2]
  def up
  end

  def down
  end
end
