closes #???

The following tasks have been completed:

 * [ ] Modified Web platform tests (link)
 
Implementation commitment:

 * [ ] WebKit (link to issue)
 * [ ] Chromium (link to issue)
 * [ ] Gecko (link to issue)

Optional, impact on Payment Handler spec?
